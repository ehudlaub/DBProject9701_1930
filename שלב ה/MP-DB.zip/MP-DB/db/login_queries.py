from db.db_connection import get_connection

def is_valid_resident(resident_id, password):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT COUNT(*) FROM resident
        WHERE residentid = %s AND password = %s
    """, (resident_id, password))
    result = cur.fetchone()[0]
    cur.close()
    conn.close()
    return result == 1

def is_valid_manager(password):
    return password == "admin123"
