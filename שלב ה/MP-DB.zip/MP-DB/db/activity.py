from db.db_connection import get_connection

class Activity:
    @staticmethod
    def get_activities_filtered(activity_id=None, title=None):
        query = "SELECT * FROM activity WHERE 1=1"
        params = []

        if activity_id:
            query += " AND activityid = %s"
            params.append(activity_id)

        if title:
            query += " AND title ILIKE %s"
            params.append(f"%{title}%")

        query += " ORDER BY activityid"

        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, params)
                return cur.fetchall()

    @staticmethod
    def add_activity(activity_id, title, start_date, end_date, location=None, instructor_id=None, max_participants=10):
        if start_date >= end_date:
            raise ValueError("Start date must be before end date")

        query = """
            INSERT INTO activity (
                activityid, title, startdate, enddate,
                activity_location, instructorid,
                maxparticipants, currentparticipants
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (
                    activity_id, title, start_date, end_date,
                    location, instructor_id,
                    max_participants, 0
                ))
            conn.commit()
    @staticmethod
    def instructor_exists(instructor_id: int) -> bool:
        query = "SELECT 1 FROM instructor WHERE instructorid = %s"
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (instructor_id,))
                return cur.fetchone() is not None

    @staticmethod
    def get_next_activity_id():
        query = "SELECT COALESCE(MAX(activityid), 1999) + 1 FROM activity"
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query)
                return cur.fetchone()[0]

    @staticmethod
    def update_activity(activity_id, title, start_date, end_date, location=None, instructor_id=None,
                        max_participants=10):
        if start_date >= end_date:
            raise ValueError("Start date must be before end date")

        query = """
            UPDATE activity
            SET title = %s,
                startdate = %s,
                enddate = %s,
                activity_location = %s,
                instructorid = %s,
                maxparticipants = %s
            WHERE activityid = %s
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (
                    title,
                    start_date,
                    end_date,
                    location,
                    instructor_id,
                    max_participants,
                    activity_id
                ))
            conn.commit()

    @staticmethod
    def get_activity_by_id(activity_id):
        query = "SELECT * FROM activity WHERE activityid = %s"
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (activity_id,))
                return cur.fetchone()

    @staticmethod
    def delete_activity(activity_id: int):
        query = "DELETE FROM activity WHERE activityid = %s"
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (activity_id,))
            conn.commit()




