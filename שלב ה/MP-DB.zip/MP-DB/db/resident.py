from .db_connection import get_connection

class Resident:
    def __init__(self, resident_id):
        self.resident_id = resident_id

    def get_registered_activities(self):
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT a.activityid, a.title, a.startdate
                    FROM participates p
                    JOIN activity a ON p.activityid = a.activityid
                    WHERE p.residentid = %s
                """, (self.resident_id,))
                return cur.fetchall()

    def get_available_activities(self):
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT a.activityid, a.title, a.startdate, a.activity_location, i.name
                    FROM activity a
                    JOIN instructor i ON a.instructorid = i.instructorid
                    WHERE a.enddate >= CURRENT_DATE
                    AND a.currentparticipants < a.maxparticipants
                    AND a.activityid NOT IN (
                        SELECT activityid FROM participates WHERE residentid = %s
                    )
                """, (self.resident_id,))
                return cur.fetchall()

    def register_to_activity(self, activity_id):
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("CALL register_resident_to_activity(%s, %s);", (self.resident_id, activity_id))
                conn.commit()

    def unregister_from_activity(self, activity_id):
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("CALL unregister_resident_from_activity(%s, %s);", (self.resident_id, activity_id))
                conn.commit()

    def get_participated_activities(self, activity_id_filter=None, instructor_id_filter=None):
        with get_connection() as conn:
            with conn.cursor() as cur:
                query = """
                    SELECT a.activityid, a.title, a.startdate, a.enddate,
                           i.instructorid, i.name
                    FROM participates p
                    JOIN activity a ON p.activityid = a.activityid
                    JOIN instructor i ON a.instructorid = i.instructorid
                    WHERE p.residentid = %s
                """
                params = [self.resident_id]

                if activity_id_filter:
                    query += " AND a.activityid = %s"
                    params.append(activity_id_filter)
                if instructor_id_filter:
                    query += " AND i.instructorid = %s"
                    params.append(instructor_id_filter)

                query += " ORDER BY a.enddate DESC"

                cur.execute(query, params)
                return cur.fetchall()

    def leave_feedback(self, activity_id, rating, comment):
        from datetime import date
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO feedback (feedbackdate, comment, rating, activityid, residentid)
                    VALUES (%s, %s, %s, %s, %s)
                """, (date.today(), comment, rating, activity_id, self.resident_id))
                conn.commit()

