from db.db_connection import get_connection

class report:

    def get_residents_with_low_feedback(resident_id=None):
        query = """
            SELECT 
                r.residentId,
                r.name,
                a.activityId,
                a.title AS activity_title,
                f.rating,
                f.comment,
                f.feedbackDate
            FROM Resident r
            JOIN Feedback f ON r.residentId = f.residentId
            JOIN Activity a ON f.activityId = a.activityId
            WHERE f.feedbackDate >= (CURRENT_DATE - INTERVAL '3 years')
              AND f.rating <= 2
        """
        params = ()
        if resident_id:
            query += " AND r.residentId = %s"
            params = (resident_id,)
        query += " ORDER BY f.feedbackDate DESC"

        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, params)
                return cur.fetchall()

    @staticmethod
    def get_new_residents_without_participation():
            query = """
                SELECT r.residentId,
                       r.name,
                       r.admissionDate,
                       EXTRACT(YEAR FROM AGE(CURRENT_DATE, r.admissionDate))::int AS years_in_home
                FROM Resident r
                LEFT JOIN Participates p ON r.residentId = p.residentId
                WHERE p.residentId IS NULL
                  AND AGE(CURRENT_DATE, r.admissionDate) < INTERVAL '3 years'
                ORDER BY r.admissionDate DESC;
            """
            with get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(query)
                    return cur.fetchall()

    @staticmethod
    def get_top_suppliers_report(supplier_id=None):
            query = """
                SELECT
                    s.supplierId,
                    s.name,
                    COUNT(*) AS supplies_count,
                    SUM(sp.cost) AS total_cost,
                    EXTRACT(YEAR FROM sp.supplyDate) AS supply_year
                FROM Supplier s
                JOIN supplies sp ON s.supplierId = sp.supplierId
                WHERE EXTRACT(YEAR FROM sp.supplyDate) = EXTRACT(YEAR FROM CURRENT_DATE)
            """
            params = []

            if supplier_id is not None:
                query += " AND s.supplierId = %s"
                params.append(supplier_id)

            query += """
                GROUP BY s.supplierId, s.name, EXTRACT(YEAR FROM sp.supplyDate)
                ORDER BY total_cost DESC;
            """

            with get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(query, params)
                    return cur.fetchall()
