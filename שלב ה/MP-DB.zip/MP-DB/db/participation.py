from .db_connection import get_connection

def get_participations(resident_id=None, activity_id=None):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT p.residentid, r.name, p.activityid, a.title, p.registrationdate
                FROM participates p
                JOIN resident r ON p.residentid = r.residentid
                JOIN activity a ON p.activityid = a.activityid
                WHERE (%s IS NULL OR p.residentid = %s)
                  AND (%s IS NULL OR p.activityid = %s)
                ORDER BY p.registrationdate DESC
            """, (resident_id, resident_id, activity_id, activity_id))
            return cur.fetchall()
