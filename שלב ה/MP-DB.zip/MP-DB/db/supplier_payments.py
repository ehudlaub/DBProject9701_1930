from .db_connection import get_connection

class SupplierPaymentHandler:
    @staticmethod
    def get_unpaid_supplies():
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        s.supplierid,
                        sp.name AS supplier_name,
                        s.supplydate,
                        s.activityid,
                        a.title AS activity_title,
                        s.cost
                    FROM supplies s
                    JOIN supplier sp ON s.supplierid = sp.supplierid
                    JOIN activity a ON s.activityid = a.activityid
                    WHERE s.waspaid = FALSE
                    ORDER BY s.supplydate DESC
                """)
                return cur.fetchall()

    @staticmethod
    def get_paid_supplies():
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                      SELECT 
                          pl.supplier_id,
                          sp.name AS supplier_name,
                          pl.supply_date,
                          pl.activity_id,
                          a.title AS activity_title,
                          pl.original_cost,
                          pl.final_paid,
                          pl.log_date
                      FROM payment_log pl
                      JOIN supplier sp ON pl.supplier_id = sp.supplierid
                      JOIN activity a ON pl.activity_id = a.activityid
                      ORDER BY pl.log_date DESC
                  """)
                return cur.fetchall()

    @staticmethod
    def mark_supply_as_paid(supplier_id, supply_date, activity_id):
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    CALL mark_supply_as_paid_row(%s, %s, %s)
                """, (supplier_id, supply_date, activity_id))

    @staticmethod
    def get_payment_amounts(supplier_id, supply_date, activity_id):
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT original, final FROM get_payment_amounts(%s, %s, %s)
                """, (supplier_id, supply_date, activity_id))
                return cur.fetchone()  # (original, final)
