import tkinter as tk
from tkinter import messagebox
from db.activity import Activity

class DeleteActivityWindow:
    def __init__(self, master):
        self.frame = tk.Frame(master)
        self.frame.pack(padx=20, pady=20)

        tk.Label(self.frame, text="Delete Activity", font=("Arial", 16)).pack(pady=(0, 10))

        entry_frame = tk.Frame(self.frame)
        entry_frame.pack(pady=5)

        tk.Label(entry_frame, text="Activity ID:").grid(row=0, column=0, sticky='e')
        self.id_entry = tk.Entry(entry_frame, width=10)
        self.id_entry.grid(row=0, column=1, padx=5)

        tk.Button(entry_frame, text="Preview", command=self.preview_activity).grid(row=0, column=2, padx=5)
        self.info_label = tk.Label(self.frame, text="", justify='left')
        self.info_label.pack(pady=10)

        tk.Button(self.frame, text="Delete", command=self.delete_activity).pack(pady=5)

    def preview_activity(self):
        activity_id_raw = self.id_entry.get().strip()
        if not activity_id_raw.isdigit():
            messagebox.showerror("Error", "Activity ID must be a number.")
            return

        activity = Activity.get_activity_by_id(int(activity_id_raw))
        if not activity:
            self.info_label.config(text="No activity found.")
            return

        info = f"Title: {activity[2]}\nStart: {activity[1]}\nEnd: {activity[3]}\n" \
               f"Location: {activity[7]}\nInstructor ID: {activity[6]}\n" \
               f"Max: {activity[4]}\nCurrent: {activity[5]}"
        self.info_label.config(text=info)

    def delete_activity(self):
        activity_id_raw = self.id_entry.get().strip()
        if not activity_id_raw.isdigit():
            messagebox.showerror("Error", "Activity ID must be a number.")
            return

        activity_id = int(activity_id_raw)
        if not Activity.get_activity_by_id(activity_id):
            messagebox.showerror("Error", f"Activity ID {activity_id} not found.")
            return

        confirm = messagebox.askyesno("Confirm", f"Are you sure you want to delete activity {activity_id}?")
        if confirm:
            Activity.delete_activity(activity_id)
            messagebox.showinfo("Deleted", f"Activity {activity_id} deleted successfully.")
            self.info_label.config(text="")
