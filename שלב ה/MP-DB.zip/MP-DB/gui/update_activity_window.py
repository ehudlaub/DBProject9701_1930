import tkinter as tk
from tkinter import messagebox
from db.activity import Activity
from datetime import datetime

class UpdateActivityWindow:
    def __init__(self, master):
        self.master = master
        self.master.title("Update Activity")
        self.frame = tk.Frame(master)
        self.frame.pack(padx=20, pady=20)

        # חיפוש לפי ID
        tk.Label(self.frame, text="Enter Activity ID:").grid(row=0, column=0, sticky='e')
        self.id_entry = tk.Entry(self.frame)
        self.id_entry.grid(row=0, column=1)
        tk.Button(self.frame, text="Load", command=self.load_activity).grid(row=0, column=2, padx=10)

        self.entries = {}
        labels = [
            ("Title", "title"),
            ("Start Date (YYYY-MM-DD)", "start"),
            ("End Date (YYYY-MM-DD)", "end"),
            ("Location", "location"),
            ("Instructor ID", "instructor"),
            ("Max Participants", "max")
        ]

        for i, (label, key) in enumerate(labels, start=1):
            tk.Label(self.frame, text=label).grid(row=i, column=0, sticky='e', pady=2)
            entry = tk.Entry(self.frame, width=30)
            entry.grid(row=i, column=1, columnspan=2, pady=2)
            self.entries[key] = entry

        tk.Button(self.frame, text="Update Activity", command=self.update_activity).grid(row=7, column=0, columnspan=3, pady=10)

    def load_activity(self):
        activity_id_raw = self.id_entry.get().strip()
        if not activity_id_raw.isdigit():
            messagebox.showerror("Error", "Activity ID must be a number.")
            return

        activity_id = int(activity_id_raw)
        data = Activity.get_activity_by_id(activity_id)

        if not data:
            messagebox.showerror("Not Found", f"No activity found with ID {activity_id}.")
            return

        # סדר השדות בהתאמה לסדר השאילתה: id, title, startdate, enddate, max, current, instructorid, location
        self.entries["title"].delete(0, tk.END)
        self.entries["title"].insert(0, data[2])

        self.entries["start"].delete(0, tk.END)
        self.entries["start"].insert(0, data[3])

        self.entries["end"].delete(0, tk.END)
        self.entries["end"].insert(0, data[1])

        self.entries["location"].delete(0, tk.END)
        self.entries["location"].insert(0, data[7] or "")

        self.entries["instructor"].delete(0, tk.END)
        if data[6]:
            self.entries["instructor"].insert(0, str(data[6]))

        self.entries["max"].delete(0, tk.END)
        self.entries["max"].insert(0, str(data[4]))

    def update_activity(self):
        activity_id_raw = self.id_entry.get().strip()
        if not activity_id_raw.isdigit():
            messagebox.showerror("Error", "Activity ID must be a number.")
            return

        activity_id = int(activity_id_raw)
        existing = Activity.get_activity_by_id(activity_id)
        if not existing:
            messagebox.showerror("Not Found", f"No activity found with ID {activity_id}.")
            return

        # קבלת נתונים קיימים
        existing_data = {
            "title": existing[2],
            "start": existing[3],
            "end": existing[1],
            "location": existing[7],
            "instructor": existing[6],
            "max": existing[4]
        }

        # בניית ערכים חדשים (או שמירה על הקיים)
        new_data = {}
        for key in self.entries:
            value = self.entries[key].get().strip()
            if value:
                new_data[key] = value
            else:
                new_data[key] = existing_data[key]

        # המרה
        try:
            new_data["start"] = datetime.strptime(new_data["start"], "%Y-%m-%d").date()
            new_data["end"] = datetime.strptime(new_data["end"], "%Y-%m-%d").date()
        except ValueError:
            messagebox.showerror("Invalid Date", "Start or end date is invalid.")
            return

        if new_data["start"] >= new_data["end"]:
            messagebox.showerror("Invalid Dates", "Start date must be before end date.")
            return

        try:
            new_data["max"] = int(new_data["max"])
        except ValueError:
            messagebox.showerror("Invalid Input", "Max Participants must be a number.")
            return

        try:
            if new_data["instructor"]:
                instructor_id = int(new_data["instructor"])
                if not Activity.instructor_exists(instructor_id):
                    messagebox.showerror("Invalid Instructor", f"Instructor ID {instructor_id} does not exist.")
                    return
                new_data["instructor"] = instructor_id
            else:
                new_data["instructor"] = None
        except ValueError:
            messagebox.showerror("Invalid Input", "Instructor ID must be a number.")
            return

        # עדכון בפועל
        try:
            Activity.update_activity(
                activity_id=activity_id,
                title=new_data["title"],
                start_date=new_data["start"],
                end_date=new_data["end"],
                location=new_data["location"],
                instructor_id=new_data["instructor"],
                max_participants=new_data["max"]
            )
            messagebox.showinfo("Success", f"Activity #{activity_id} updated successfully.")
        except Exception as e:
            messagebox.showerror("Database Error", str(e))
