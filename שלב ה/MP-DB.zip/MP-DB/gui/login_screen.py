import tkinter as tk
from tkinter import messagebox
from db.login_queries import is_valid_resident, is_valid_manager
from gui.resident_screen import ResidentScreen
from gui.Manager_Screen import ManagerScreen


class LoginScreen:
    def __init__(self, master):
        self.master = master
        master.title("Welcome to the Activity Management System")
        master.geometry("400x300")

        self.title_label = tk.Label(master, text="Welcome to the Activity Management System", font=("Arial", 12))
        self.title_label.pack(pady=10)

        self.role_var = tk.StringVar(value="none")

        self.role_frame = tk.Frame(master)
        self.role_frame.pack()

        self.manager_radio = tk.Radiobutton(self.role_frame, text="Manager", variable=self.role_var, value="manager", command=self.show_fields)
        self.manager_radio.grid(row=0, column=0, padx=10)

        self.resident_radio = tk.Radiobutton(self.role_frame, text="Resident", variable=self.role_var, value="resident", command=self.show_fields)
        self.resident_radio.grid(row=0, column=1, padx=10)

        self.form_frame = tk.Frame(master)
        self.form_frame.pack(pady=20)

        self.id_label = tk.Label(self.form_frame, text="ID:")
        self.id_entry = tk.Entry(self.form_frame)

        self.password_label = tk.Label(self.form_frame, text="Password:")
        self.password_entry = tk.Entry(self.form_frame, show="*")

        self.login_button = tk.Button(master, text="Login", command=self.login)
        self.login_button.pack(pady=10)

    def show_fields(self):
        for widget in self.form_frame.winfo_children():
            widget.grid_forget()

        role = self.role_var.get()
        if role == "resident":
            self.id_label.grid(row=0, column=0, sticky="e")
            self.id_entry.grid(row=0, column=1)
            self.password_label.grid(row=1, column=0, sticky="e")
            self.password_entry.grid(row=1, column=1)
        elif role == "manager":
            self.password_label.grid(row=0, column=0, sticky="e")
            self.password_entry.grid(row=0, column=1)

    def login(self):
        role = self.role_var.get()
        if role == "none":
            messagebox.showerror("Error", "Please select a role.")
            return

        if role == "resident":
            user_id = self.id_entry.get()
            password = self.password_entry.get()
            messagebox.showinfo("Login", f"Logging in as Resident\nID: {user_id}")
        elif role == "manager":
            password = self.password_entry.get()
            messagebox.showinfo("Login", "Logging in as Manager")


    def login(self):
        role = self.role_var.get()

        if role == "none":
            messagebox.showerror("Error", "Please select a role.")
            return

        password = self.password_entry.get()

        if role == "resident":
            user_id = self.id_entry.get()
            if not user_id:
                messagebox.showerror("Error", "Please enter your ID")
                return
            if is_valid_resident(user_id, password):
                self.master.destroy()
                root = tk.Tk()
                ResidentScreen(root, user_id)
                root.mainloop()
            else:
                messagebox.showerror("Error", "Invalid credentials")

        elif role == "manager":
            if is_valid_manager(password):
                self.master.destroy()
                root = tk.Tk()
                ManagerScreen(root)
                root.mainloop()
            else:
                messagebox.showerror("Error", "Wrong manager password")

