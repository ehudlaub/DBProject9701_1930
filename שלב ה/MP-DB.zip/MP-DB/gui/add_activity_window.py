import tkinter as tk
from tkinter import messagebox
from db.activity import Activity
from datetime import datetime

class AddActivityWindow:
    def __init__(self, master):
        self.frame = tk.Frame(master)
        self.frame.pack(padx=20, pady=20, fill='both', expand=True)

        tk.Label(self.frame, text="Add New Activity", font=("Arial", 16)).pack(pady=(0, 20))

        form = tk.Frame(self.frame)
        form.pack()

        self.entries = {}

        def add_labeled_entry(row, label_text, key, default=""):
            tk.Label(form, text=label_text, anchor='e', width=20).grid(row=row, column=0, sticky='e', pady=3)
            entry = tk.Entry(form, width=30)
            entry.insert(0, default)
            entry.grid(row=row, column=1, pady=3)
            self.entries[key] = entry

        add_labeled_entry(0, "Title *", "title")
        add_labeled_entry(1, "Start Date (YYYY-MM-DD) *", "start")
        add_labeled_entry(2, "End Date (YYYY-MM-DD) *", "end")
        add_labeled_entry(3, "Location", "location")
        add_labeled_entry(4, "Instructor ID *", "instructor")
        add_labeled_entry(5, "Max Participants", "max")

        tk.Button(self.frame, text="Add Activity", command=self.add_activity).pack(pady=10)

    def add_activity(self):
        title = self.entries["title"].get().strip()
        start = self.entries["start"].get().strip()
        end = self.entries["end"].get().strip()
        location = self.entries["location"].get().strip() or None
        instructor_id_raw = self.entries["instructor"].get().strip()
        max_participants_raw = self.entries["max"].get().strip()

        # Validation: Required fields
        if not title or not start or not end:
            messagebox.showerror("Missing Data", "Please fill in all required fields.")
            return

        # Validation: Date format
        try:
            start_date = datetime.strptime(start, "%Y-%m-%d").date()
            end_date = datetime.strptime(end, "%Y-%m-%d").date()
        except ValueError:
            messagebox.showerror("Invalid Date", "Please enter dates in YYYY-MM-DD format.")
            return

        if start_date >= end_date:
            messagebox.showerror("Invalid Dates", "Start date must be before end date.")
            return

        # Validation: Instructor
        if not instructor_id_raw:
            messagebox.showerror("Missing Data", "Instructor ID is required.")
            return

        try:
            instructor_id = int(instructor_id_raw)
        except ValueError:
            messagebox.showerror("Invalid Input", "Instructor ID must be a number.")
            return

        if not Activity.instructor_exists(instructor_id):
            messagebox.showerror("Invalid Instructor", f"Instructor ID {instructor_id} does not exist.")
            return

        # Validation: Max Participants
        try:
            max_participants = int(max_participants_raw) if max_participants_raw else 10
        except ValueError:
            messagebox.showerror("Invalid Input", "Max Participants must be a number.")
            return

        # Get next activity ID
        try:
            new_id = Activity.get_next_activity_id()
        except Exception as e:
            messagebox.showerror("Database Error", f"Failed to fetch next activity ID:\n{e}")
            return

        # Insert into DB
        try:
            Activity.add_activity(
                activity_id=new_id,
                title=title,
                start_date=start_date,
                end_date=end_date,
                location=location,
                instructor_id=instructor_id,
                max_participants=max_participants
            )
            messagebox.showinfo("Success", f"Activity #{new_id} added successfully.")
        except Exception as e:
            messagebox.showerror("Database Error", str(e))
