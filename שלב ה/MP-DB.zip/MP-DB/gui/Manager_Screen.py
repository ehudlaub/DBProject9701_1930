import tkinter as tk
from gui.join_activity_by_manager import JoinActivityByManager
from gui.remove_activity_by_manager import RemoveActivityByManager
from gui.view_participations_window import ViewParticipationsWindow
from gui.unpaid_supplies_window import UnpaidSuppliesWindow
from gui.paid_supplies_window import PaidSuppliesWindow
from gui.pay_supplier_window import PaySupplierWindow
from gui.View_Activities_Window import ViewActivitiesWindow
from gui.add_activity_window import AddActivityWindow
from gui.update_activity_window import UpdateActivityWindow
from gui.delete_activity_window import DeleteActivityWindow
from gui.instructor_report_window import InstructorReportWindow
from gui.low_feedback_window import LowFeedbackWindow
from gui.inactive_residents_window import InactiveResidentsWindow
from gui.top_suppliers_report_window import TopSuppliersReportWindow


class ManagerScreen:
    def __init__(self, master):
        self.master = master
        master.title("Manager Dashboard")
        master.geometry("500x700")

        main_frame = tk.Frame(master, padx=20, pady=20)
        main_frame.pack(fill='both', expand=True)

        # ----------------------------
        # Section: Participation Management
        # ----------------------------
        tk.Label(main_frame, text="Participation Management", font=("Arial", 14, "bold")).pack(anchor='w', pady=(10, 5))
        tk.Button(main_frame, text="Register Resident to Activity", width=35, command=self.open_join_window).pack(pady=2)
        tk.Button(main_frame, text="Remove Resident from Activity", width=35, command=self.open_remove_window).pack(pady=2)
        tk.Button(main_frame, text="View Participations", width=35, command=self.open_view_participations).pack(pady=2)

        # ----------------------------
        # Section: Activity Management
        # ----------------------------
        tk.Label(main_frame, text="Activity Management", font=("Arial", 14, "bold")).pack(anchor='w', pady=(20, 5))
        tk.Button(main_frame, text="Add Activity", width=35, command=self.open_add_activity).pack(pady=2)
        tk.Button(main_frame, text="Update Activity", width=35, command=self.open_update_activity).pack(pady=2)
        tk.Button(main_frame, text="Delete Activity", width=35, command=self.open_delete_activity).pack(pady=2)
        tk.Button(main_frame, text="View All Activities", width=35, command=self.open_view_activities).pack(pady=2)

        # ----------------------------
        # Section: Supplier Payments
        # ----------------------------
        tk.Label(main_frame, text="Supplier Payments", font=("Arial", 14, "bold")).pack(anchor='w', pady=(20, 5))
        tk.Button(main_frame, text="View Pending Payments", width=35, command=self.open_pending_payments).pack(pady=2)
        tk.Button(main_frame, text="View Paid Transactions", width=35, command=self.open_paid_transactions).pack(pady=2)
        tk.Button(main_frame, text="Pay for a Transaction", width=35, command=self.open_pay_supplier).pack(pady=2)

        # ----------------------------
        # Section: Dashboard and Reports
        # ----------------------------
        tk.Label(main_frame, text="Dashboard & Reports", font=("Arial", 14, "bold")).pack(anchor='w', pady=(20, 5))
        tk.Button(main_frame, text="Instructor Report", width=35, command=self.open_instructor_report).pack(pady=2)
        tk.Button(main_frame, text="Residents with Low Feedback", width=35, command=self.open_low_feedback_residents).pack(pady=2)
        tk.Button(main_frame, text="New Residents with No Participation", width=35, command=self.open_inactive_residents).pack(pady=2)
        tk.Button(main_frame, text="Top Active Suppliers", width=35, command=self.open_top_suppliers).pack(pady=2)

    def open_join_window(self):
        top = tk.Toplevel(self.master)
        JoinActivityByManager(top).frame.pack(fill='both', expand=True)

    def open_remove_window(self):
        top = tk.Toplevel(self.master)
        RemoveActivityByManager(top).frame.pack(fill='both', expand=True)

    def open_view_participations(self):
        top = tk.Toplevel(self.master)
        ViewParticipationsWindow(top)

    def open_add_activity(self):
        top = tk.Toplevel(self.master)
        AddActivityWindow(top)

    def open_update_activity(self):
        top = tk.Toplevel(self.master)
        UpdateActivityWindow(top)

    def open_delete_activity(self):
        top = tk.Toplevel(self.master)
        DeleteActivityWindow(top)

    def open_view_activities(self):
        top = tk.Toplevel(self.master)
        ViewActivitiesWindow(top)

    def open_pending_payments(self):
        top = tk.Toplevel(self.master)
        UnpaidSuppliesWindow(top)

    def open_paid_transactions(self):
        top = tk.Toplevel(self.master)
        PaidSuppliesWindow(top)

    def open_pay_supplier(self):
        top = tk.Toplevel(self.master)
        PaySupplierWindow(top)

    def open_instructor_report(self):
        top = tk.Toplevel(self.master)
        InstructorReportWindow(top)

    def open_low_feedback_residents(self):
        top = tk.Toplevel(self.master)
        LowFeedbackWindow(top)

    def open_inactive_residents(self):
        top = tk.Toplevel(self.master)
        InactiveResidentsWindow(top)

    def open_top_suppliers(self):
        top = tk.Toplevel(self.master)
        TopSuppliersReportWindow(top)

