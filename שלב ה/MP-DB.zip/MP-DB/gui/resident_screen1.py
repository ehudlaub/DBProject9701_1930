import tkinter as tk
from tkinter import messagebox
from db.resident import Resident

class ResidentScreen:
    def __init__(self, master, resident_id):
        self.master = master
        self.master.title(f"Resident Dashboard - ID {resident_id}")
        self.resident = Resident(resident_id)

        tk.Label(master, text="Your Registered Activities", font=("Arial", 12, "bold")).pack(pady=5)
        self.registered_listbox = tk.Listbox(master, width=50)
        self.registered_listbox.pack()

        tk.Label(master, text="Available Activities to Join", font=("Arial", 12, "bold")).pack(pady=5)
        self.available_listbox = tk.Listbox(master, width=50)
        self.available_listbox.pack()

        self.join_button = tk.Button(master, text="Join Selected Activity", command=self.join_selected_activity)
        self.join_button.pack(pady=10)

        self.refresh()

    def refresh(self):
        self.registered_listbox.delete(0, tk.END)
        for act in self.resident.get_registered_activities():
            self.registered_listbox.insert(tk.END, f"{act[0]} - {act[1]} ({act[2]})")

        self.available_listbox.delete(0, tk.END)
        for act in self.resident.get_available_activities():
            self.available_listbox.insert(tk.END, f"{act[0]} - {act[1]} ({act[2]})")

    def join_selected_activity(self):
        selection = self.available_listbox.curselection()
        if not selection:
            messagebox.showwarning("No selection", "Please select an activity to join.")
            return

        selected_text = self.available_listbox.get(selection[0])
        activity_id = int(selected_text.split(" - ")[0])

        try:
            self.resident.register_to_activity(activity_id)
            messagebox.showinfo("Success", f"Successfully registered to activity {activity_id}.")
            self.refresh()
        except Exception as e:
            messagebox.showerror("Error", str(e))
