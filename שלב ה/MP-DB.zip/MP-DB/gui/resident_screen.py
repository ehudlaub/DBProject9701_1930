import tkinter as tk
from gui.join_activity_window import JoinActivityWindow
from gui.remove_activity_window import RemoveActivityWindow
from gui.leave_feedback_window import LeaveFeedbackWindow

class ResidentScreen:
    def __init__(self, master, resident_id):
        self.master = master
        self.resident_id = resident_id
        master.title("Resident Dashboard")
        master.geometry("400x250")

        tk.Label(master, text="Welcome Resident", font=("Arial", 16)).pack(pady=20)

        tk.Button(master, text="Join an Activity", width=20, command=self.open_join_window).pack(pady=10)

        tk.Button(master, text="Remove Participation", width=20, command=self.open_remove_window).pack(pady=10)

        tk.Button(master, text="Leave Feedback", width=20, command=self.open_feedback_window).pack(pady=10)

    def open_join_window(self):
        join_window = tk.Toplevel(self.master)
        join_tab = JoinActivityWindow(join_window, self.resident_id)
        join_tab.frame.pack(fill='both', expand=True)

    def open_remove_window(self):
        remove_window = tk.Toplevel(self.master)
        tab = RemoveActivityWindow(remove_window, self.resident_id)
        tab.frame.pack(fill='both', expand=True)

    from gui.leave_feedback_window import LeaveFeedbackWindow


    def open_feedback_window(self):
        feedback_window = tk.Toplevel(self.master)
        feedback_tab = LeaveFeedbackWindow(feedback_window, self.resident_id)
        feedback_tab.frame.pack(fill='both', expand=True)

