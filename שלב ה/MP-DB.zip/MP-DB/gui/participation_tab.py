import tkinter as tk
from tkinter import ttk, messagebox
from db.resident import Resident

class ParticipationTab:
    def __init__(self, parent):
        self.frame = ttk.Frame(parent)

        self.mode_var = tk.StringVar(value="resident")
        self.resident_id_var = tk.StringVar()

        # מצב בחירה בין דייר לפעילות
        top_frame = tk.Frame(self.frame)
        top_frame.pack(anchor="w", padx=10, pady=10)

        tk.Label(top_frame, text="Select Mode:").pack(side="left", padx=(0, 5))
        mode_menu = ttk.Combobox(top_frame, textvariable=self.mode_var, values=["resident"], state="readonly", width=12)
        mode_menu.pack(side="left")
        mode_menu.bind("<<ComboboxSelected>>", self.switch_mode)

        # הזנת תז וכפתור
        tk.Label(top_frame, text="  Enter Resident ID:").pack(side="left")
        tk.Entry(top_frame, textvariable=self.resident_id_var, width=10).pack(side="left", padx=5)
        tk.Button(top_frame, text="Load", command=self.load_resident_data).pack(side="left", padx=(5, 0))

        # Frame לפי דייר
        self.by_resident_frame = tk.Frame(self.frame, padx=20, pady=10)
        self.by_resident_frame.pack(fill='both', expand=True)

        # טבלת פעילויות רשומות
        tk.Label(self.by_resident_frame, text="Registered Activities:").pack(anchor="w", pady=(10, 5))
        self.registered_listbox = tk.Listbox(self.by_resident_frame, width=80, height=6)
        self.registered_listbox.pack(fill="x", padx=5, pady=5)
        tk.Button(self.by_resident_frame, text="Unregister Selected", command=self.unregister_activity).pack(pady=10)

        # טבלת פעילויות זמינות
        tk.Label(self.by_resident_frame, text="Available Activities:").pack(anchor="w", pady=(10, 5))
        self.available_listbox = tk.Listbox(self.by_resident_frame, width=80, height=6)
        self.available_listbox.pack(fill="x", padx=5, pady=5)
        tk.Button(self.by_resident_frame, text="Register to Selected Activity", command=self.register_selected_activity).pack(pady=10)

    def switch_mode(self, event):
        pass

    def load_resident_data(self):
        self.registered_listbox.delete(0, tk.END)
        self.available_listbox.delete(0, tk.END)
        try:
            resident_id = int(self.resident_id_var.get())
            self.resident = Resident(resident_id)
            for row in self.resident.get_registered_activities():
                self.registered_listbox.insert(tk.END, f"{row[0]} - {row[1]} ({row[4]})")
            for activity in self.resident.get_available_activities():
                self.available_listbox.insert(tk.END, f"{activity[0]} - {activity[1]} ({activity[2]})")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def unregister_activity(self):
        selection = self.registered_listbox.get(tk.ACTIVE)
        if not selection:
            messagebox.showwarning("Warning", "Please select an activity to unregister.")
            return
        activity_id = int(selection.split(" - ")[0])
        try:
            self.resident.unregister_from_activity(activity_id)
            self.load_resident_data()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def register_selected_activity(self):
        selection = self.available_listbox.get(tk.ACTIVE)
        if not selection:
            messagebox.showwarning("Warning", "Please select an activity to register.")
            return
        activity_id = int(selection.split(" - ")[0])
        try:
            self.resident.register_to_activity(activity_id)
            messagebox.showinfo("Success", "Resident registered successfully.")
            self.load_resident_data()
        except Exception as e:
            messagebox.showerror("Error", str(e))
