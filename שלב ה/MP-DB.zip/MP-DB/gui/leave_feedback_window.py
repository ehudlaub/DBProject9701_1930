import tkinter as tk
from tkinter import ttk, messagebox
from db.resident import Resident

class LeaveFeedbackWindow:
    def __init__(self, parent, resident_id):
        self.frame = tk.Frame(parent)
        self.resident = Resident(resident_id)

        tk.Label(self.frame, text="Leave Feedback", font=("Arial", 16)).pack(pady=10)

        # סינון
        filter_frame = tk.Frame(self.frame)
        filter_frame.pack(pady=5)

        tk.Label(filter_frame, text="Activity ID:").grid(row=0, column=0, padx=5)
        self.activity_id_entry = tk.Entry(filter_frame, width=10)
        self.activity_id_entry.grid(row=0, column=1, padx=5)

        tk.Label(filter_frame, text="Instructor ID:").grid(row=0, column=2, padx=5)
        self.instructor_id_entry = tk.Entry(filter_frame, width=10)
        self.instructor_id_entry.grid(row=0, column=3, padx=5)

        tk.Button(filter_frame, text="Load", command=self.load_activities).grid(row=0, column=4, padx=10)

        # טבלה
        columns = ("activityid", "title", "startdate", "enddate", "instructorid", "instructorname")
        self.tree = ttk.Treeview(self.frame, columns=columns, show="headings", height=10)
        for col in columns:
            self.tree.heading(col, text=col.capitalize())
            self.tree.column(col, anchor="center")
        self.tree.pack(pady=10, fill="x")

        # דירוג והערה
        input_frame = tk.Frame(self.frame)
        input_frame.pack()

        tk.Label(input_frame, text="Rating (1–5):").grid(row=0, column=0, padx=5)
        self.rating_entry = tk.Entry(input_frame, width=5)
        self.rating_entry.grid(row=0, column=1, padx=5)

        tk.Label(input_frame, text="Comment:").grid(row=0, column=2, padx=5)
        self.comment_entry = tk.Entry(input_frame, width=40)
        self.comment_entry.grid(row=0, column=3, padx=5)

        tk.Button(self.frame, text="Submit Feedback", command=self.submit_feedback).pack(pady=10)

        self.activities = []
        self.load_activities()

    def load_activities(self):
        self.tree.delete(*self.tree.get_children())

        try:
            act_id = int(self.activity_id_entry.get()) if self.activity_id_entry.get() else None
        except ValueError:
            messagebox.showerror("Invalid", "Activity ID must be a number.")
            return

        try:
            inst_id = int(self.instructor_id_entry.get()) if self.instructor_id_entry.get() else None
        except ValueError:
            messagebox.showerror("Invalid", "Instructor ID must be a number.")
            return

        self.activities = self.resident.get_participated_activities(act_id, inst_id)
        for row in self.activities:
            self.tree.insert("", "end", values=row)

    def submit_feedback(self):
        selected = self.tree.focus()
        if not selected:
            messagebox.showwarning("Warning", "Select an activity from the table.")
            return

        try:
            rating = int(self.rating_entry.get())
            if rating < 1 or rating > 5:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Rating", "Rating must be between 1–5.")
            return

        comment = self.comment_entry.get().strip()
        if not comment:
            messagebox.showwarning("Empty", "Please enter a comment.")
            return

        index = self.tree.index(selected)
        activity_id = self.activities[index][0]

        try:
            self.resident.leave_feedback(activity_id, rating, comment)
            messagebox.showinfo("Success", "Feedback submitted.")
        except Exception as e:
            messagebox.showerror("Error", str(e))
