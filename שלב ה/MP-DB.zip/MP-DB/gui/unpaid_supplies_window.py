# gui/unpaid_supplies_window.py

import tkinter as tk
from tkinter import ttk
from db.supplier_payments import SupplierPaymentHandler


class UnpaidSuppliesWindow:
    def __init__(self, master):
        self.master = master
        master.title("Unpaid Supplies")

        self.frame = tk.Frame(master)
        self.frame.pack(fill='both', expand=True)

        tk.Label(self.frame, text="Unpaid Supplies", font=('Arial', 14)).pack(pady=10)

        columns = ("supplier_id", "supplier_name", "supply_date", "activity_id", "activity_title", "cost")
        self.tree = ttk.Treeview(self.frame, columns=columns, show='headings')
        for col in columns:
            self.tree.heading(col, text=col.replace("_", " ").title())
            self.tree.column(col, anchor="center")

        self.tree.pack(fill='both', expand=True, padx=10, pady=10)

        self.load_data()

    def load_data(self):
        records = SupplierPaymentHandler.get_unpaid_supplies()
        for row in records:
            self.tree.insert('', tk.END, values=row)
