import tkinter as tk
from tkinter import ttk
from db.supplier_payments import SupplierPaymentHandler

class PaidSuppliesWindow:
    def __init__(self, master):
        self.master = master
        master.title("Paid Supplies")

        self.frame = tk.Frame(master)
        self.frame.pack(fill='both', expand=True, padx=10, pady=10)

        tk.Label(self.frame, text="Paid Supplies", font=("Arial", 14)).pack(pady=10)

        self.setup_table()
        self.load_data()

    def setup_table(self):
        columns = ("supplier_id", "supplier_name", "supply_date", "activity_id",
                   "activity_title", "original_cost", "final_paid", "log_date")

        self.tree = ttk.Treeview(self.frame, columns=columns, show="headings")

        self.tree.heading("supplier_id", text="Supplier Id")
        self.tree.column("supplier_id", width=80, anchor='center')

        self.tree.heading("supplier_name", text="Supplier Name")
        self.tree.column("supplier_name", width=180)

        self.tree.heading("supply_date", text="Supply Date")
        self.tree.column("supply_date", width=100, anchor='center')

        self.tree.heading("activity_id", text="Activity Id")
        self.tree.column("activity_id", width=80, anchor='center')

        self.tree.heading("activity_title", text="Activity Title")
        self.tree.column("activity_title", width=160)

        self.tree.heading("original_cost", text="Original Cost")
        self.tree.column("original_cost", width=100, anchor='e')

        self.tree.heading("final_paid", text="Final Paid")
        self.tree.column("final_paid", width=100, anchor='e')

        self.tree.heading("log_date", text="Log Date")
        self.tree.column("log_date", width=100, anchor='center')

        self.tree.pack(fill="both", expand=True)


    def load_data(self):
        records = SupplierPaymentHandler.get_paid_supplies()
        for row in records:
            self.tree.insert('', tk.END, values=row)
