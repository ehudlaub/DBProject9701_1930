# gui/inactive_residents_window.py
import tkinter as tk
from tkinter import ttk
from db.Report import report

class InactiveResidentsWindow:
    def __init__(self, master):
        self.master = master
        master.title("New Residents with No Participation")

        frame = tk.Frame(master, padx=10, pady=10)
        frame.pack(fill='both', expand=True)

        self.tree = ttk.Treeview(frame, columns=("id", "name", "admission", "years"), show="headings")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
        self.tree.pack(fill='both', expand=True, pady=5)

        self.load_data()

    def load_data(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        results = report.get_new_residents_without_participation()
        for row in results:
            self.tree.insert("", "end", values=row)
