import tkinter as tk
from tkinter import ttk, messagebox
from db.db_connection import get_connection

class InstructorReportWindow:
    def __init__(self, master):
        self.master = master
        master.title("Instructor Report")

        # Filter Frame
        filter_frame = tk.Frame(master)
        filter_frame.pack(padx=20, pady=(15, 0), fill='x')

        tk.Label(filter_frame, text="Filter by Instructor ID:").pack(side='left')
        self.id_entry = tk.Entry(filter_frame, width=10)
        self.id_entry.pack(side='left', padx=5)
        tk.Button(filter_frame, text="Search", command=self.load_data).pack(side='left')

        # Treeview
        self.tree = ttk.Treeview(master, columns=("id", "name", "activities", "experience", "feedback", "participants"), show='headings')
        for col, label in zip(self.tree["columns"],
                              ["ID", "Name", "Total Activities", "Years of Experience", "Avg Feedback", "Avg Participants"]):
            self.tree.heading(col, text=label)
        self.tree.pack(fill='both', expand=True, padx=20, pady=20)

        self.load_data()

    def load_data(self):
        id_filter = self.id_entry.get().strip()

        try:
            with get_connection() as conn:
                with conn.cursor() as cur:
                    if id_filter.isdigit():
                        cur.execute("""
                            SELECT * FROM get_all_instructors_report()
                            WHERE instructorid = %s
                        """, (int(id_filter),))
                    else:
                        cur.execute("SELECT * FROM get_all_instructors_report()")
                    rows = cur.fetchall()
                    self.tree.delete(*self.tree.get_children())
                    for row in rows:
                        self.tree.insert('', 'end', values=row)
        except Exception as e:
            messagebox.showerror("Error", str(e))
