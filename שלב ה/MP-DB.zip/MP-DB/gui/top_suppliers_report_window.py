import tkinter as tk
from tkinter import ttk
from db.Report import report

class TopSuppliersReportWindow:
    def __init__(self, master):
        self.frame = tk.Frame(master)
        self.frame.pack(padx=20, pady=20, fill='both', expand=True)

        filter_frame = tk.Frame(self.frame)
        filter_frame.pack(pady=10)

        tk.Label(filter_frame, text="Supplier ID:").grid(row=0, column=0, padx=5)
        self.id_entry = tk.Entry(filter_frame, width=10)
        self.id_entry.grid(row=0, column=1, padx=5)

        tk.Button(filter_frame, text="Load", command=self.load_data).grid(row=0, column=2, padx=10)

        # טבלה
        columns = ("supplierId", "name", "supplies_count", "total_cost", "supply_year")
        self.tree = ttk.Treeview(self.frame, columns=columns, show='headings')
        for col in columns:
            self.tree.heading(col, text=col.replace('_', ' ').title())
            self.tree.column(col, anchor='center')

        self.tree.pack(fill='both', expand=True)
        self.load_data()

    def load_data(self):
        supplier_id = self.id_entry.get().strip()
        supplier_id = int(supplier_id) if supplier_id.isdigit() else None

        for row in self.tree.get_children():
            self.tree.delete(row)

        rows = report.get_top_suppliers_report(supplier_id)
        for row in rows:
            self.tree.insert('', 'end', values=row)
