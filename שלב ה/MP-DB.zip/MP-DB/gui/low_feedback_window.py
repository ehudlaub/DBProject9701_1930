import tkinter as tk
from tkinter import ttk
from db.Report import report

class LowFeedbackWindow:
    def __init__(self, master):
        self.master = master
        master.title("Residents with Low Feedback")

        frame = tk.Frame(master, padx=10, pady=10)
        frame.pack(fill='both', expand=True)

        filter_frame = tk.Frame(frame)
        filter_frame.pack(pady=5)

        tk.Label(filter_frame, text="Resident ID:").grid(row=0, column=0)
        self.resident_id_entry = tk.Entry(filter_frame, width=10)
        self.resident_id_entry.grid(row=0, column=1, padx=5)
        tk.Button(filter_frame, text="Search", command=self.load_data).grid(row=0, column=2)

        self.tree = ttk.Treeview(frame, columns=("id", "name", "activity", "title", "rating", "comment", "date"), show="headings")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
        self.tree.pack(fill='both', expand=True, pady=5)

        self.load_data()

    def load_data(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        resident_id = self.resident_id_entry.get()
        resident_id = int(resident_id) if resident_id.isdigit() else None

        results = report.get_residents_with_low_feedback(resident_id)
        for row in results:
            self.tree.insert("", "end", values=row)
