import tkinter as tk
from tkinter import ttk
from db.participation import get_participations

class ViewParticipationsWindow:
    def __init__(self, master):
        self.frame = tk.Frame(master)
        self.frame.pack(fill='both', expand=True, padx=20, pady=20)

        filter_frame = tk.Frame(self.frame)
        filter_frame.pack(pady=10)

        tk.Label(filter_frame, text="Resident ID:").grid(row=0, column=0, sticky='e')
        self.resident_id_entry = tk.Entry(filter_frame, width=15)
        self.resident_id_entry.grid(row=0, column=1, padx=5)

        tk.Label(filter_frame, text="Activity ID:").grid(row=0, column=2, sticky='e')
        self.activity_id_entry = tk.Entry(filter_frame, width=15)
        self.activity_id_entry.grid(row=0, column=3, padx=5)

        tk.Button(filter_frame, text="Search", command=self.load_participations).grid(row=0, column=4, padx=10)

        self.tree = ttk.Treeview(self.frame, columns=("residentid", "name", "activityid", "title", "date"), show='headings')
        self.tree.pack(fill='both', expand=True)

        for col in self.tree["columns"]:
            self.tree.heading(col, text=col.capitalize())

        self.load_participations()

    def load_participations(self):
        rid = self.resident_id_entry.get().strip()
        aid = self.activity_id_entry.get().strip()

        rid_val = int(rid) if rid.isdigit() else None
        aid_val = int(aid) if aid.isdigit() else None

        results = get_participations(rid_val, aid_val)

        self.tree.delete(*self.tree.get_children())
        for row in results:
            self.tree.insert('', 'end', values=row)
