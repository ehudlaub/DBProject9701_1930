import tkinter as tk
from tkinter import ttk, messagebox
from db.resident import Resident

class JoinActivityWindow:
    def __init__(self, parent, resident_id):
        self.frame = ttk.Frame(parent)
        self.resident = Resident(resident_id)

        tk.Label(self.frame, text="Join an Activity", font=("Arial", 16)).pack(pady=10)

        self.activities_listbox = tk.Listbox(self.frame, height=15, width=80)
        self.activities_listbox.pack(pady=10)

        self.join_button = tk.Button(self.frame, text="Join Selected Activity", command=self.join_selected_activity)
        self.join_button.pack(pady=5)

        self.load_activities()

    def load_activities(self):
        self.activities_listbox.delete(0, tk.END)
        self.activities = self.resident.get_available_activities()
        for act in self.activities:
            display = f"{act[1]} - {act[2]} | {act[3]} | {act[4]}"
            self.activities_listbox.insert(tk.END, display)


    def join_selected_activity(self):
        selection = self.activities_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select an activity.")
            return

        index = selection[0]
        activity_id = self.activities[index][0]

        try:
            self.resident.register_to_activity(activity_id)
            messagebox.showinfo("Success", "Successfully registered to the activity.")
            self.load_activities()  # רענון הרשימה
        except Exception as e:
            messagebox.showerror("Error", f"Failed to register: {e}")
