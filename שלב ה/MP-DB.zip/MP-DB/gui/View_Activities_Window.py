import tkinter as tk
from tkinter import ttk
from db.activity import Activity

class ViewActivitiesWindow:
    def __init__(self, master):
        self.frame = tk.Frame(master)
        self.frame.pack(fill='both', expand=True, padx=20, pady=20)

        # Filters
        filter_frame = tk.Frame(self.frame)
        filter_frame.pack(pady=10)

        tk.Label(filter_frame, text="Activity ID:").grid(row=0, column=0, sticky='e')
        self.id_entry = tk.Entry(filter_frame, width=10)
        self.id_entry.grid(row=0, column=1, padx=5)

        tk.Label(filter_frame, text="Title:").grid(row=0, column=2, sticky='e')
        self.title_entry = tk.Entry(filter_frame, width=20)
        self.title_entry.grid(row=0, column=3, padx=5)

        tk.Button(filter_frame, text="Search", command=self.load_activities).grid(row=0, column=4, padx=10)

        # Tree
        self.tree = ttk.Treeview(self.frame, columns=(
            "id", "title", "start", "end", "max", "current", "instructor", "location"
        ), show='headings')
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col.capitalize())
            self.tree.column(col, anchor='center', width=100)
        self.tree.pack(fill='both', expand=True)

        self.load_activities()

    def load_activities(self):
        activity_id = self.id_entry.get()
        title = self.title_entry.get()

        id_val = int(activity_id) if activity_id.isdigit() else None
        title_val = title.strip() if title.strip() else None

        rows = Activity.get_activities_filtered(id_val, title_val)

        # Clear table
        for row in self.tree.get_children():
            self.tree.delete(row)

        for row in rows:
            self.tree.insert('', 'end', values=(
                row[0],  # id
                row[2],  # title
                row[3],  # start
                row[1],  # end
                row[4],  # max
                row[5],  # current
                row[6],  # instructor
                row[7],  # location
            ))


