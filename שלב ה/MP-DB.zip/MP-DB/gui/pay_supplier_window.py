import tkinter as tk
from tkinter import ttk, messagebox
from db.supplier_payments import SupplierPaymentHandler

class PaySupplierWindow:
    def __init__(self, master):
        self.master = master
        master.title("Pay for a Supply Transaction")

        self.frame = tk.Frame(master, padx=20, pady=20)
        self.frame.pack(fill='both', expand=True)

        tk.Label(self.frame, text="Select a Supply to Pay", font=("Arial", 14)).pack(pady=10)

        self.tree = ttk.Treeview(self.frame, columns=("supplier_id", "supply_date", "activity_id"), show='headings')
        self.tree.heading("supplier_id", text="Supplier ID")
        self.tree.heading("supply_date", text="Supply Date")
        self.tree.heading("activity_id", text="Activity ID")
        self.tree.pack(fill='both', expand=True, pady=10)

        tk.Button(self.frame, text="Pay", command=self.pay_selected).pack()

        self.load_unpaid()

    def load_unpaid(self):
        records = SupplierPaymentHandler.get_unpaid_supplies()
        for row in records:
            supplier_id, _, supply_date, activity_id, *_ = row
            self.tree.insert('', 'end', values=(supplier_id, supply_date, activity_id))

    def pay_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No selection", "Please select a supply to pay.")
            return

        values = self.tree.item(selected[0], 'values')
        supplier_id, supply_date, activity_id = values

        try:
            original, paid_amount = SupplierPaymentHandler.get_payment_amounts(supplier_id, supply_date, activity_id)
            SupplierPaymentHandler.mark_supply_as_paid(supplier_id, supply_date, activity_id)
            messagebox.showinfo("Success",
                                f"Supply marked as paid.\nOriginal cost: ₪{original}\nFinal amount paid: ₪{paid_amount}")
            self.tree.delete(selected[0])
        except Exception as e:
            messagebox.showerror("Error", str(e))

