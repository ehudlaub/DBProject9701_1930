import tkinter as tk
from tkinter import ttk, messagebox
from db.resident import Resident

class RemoveActivityWindow:
    def __init__(self, master, resident_id):
        self.frame = ttk.Frame(master)
        self.resident = Resident(resident_id)

        tk.Label(self.frame, text="Remove Participation", font=("Arial", 16)).pack(pady=10)

        self.activities_listbox = tk.Listbox(self.frame, height=15, width=80)
        self.activities_listbox.pack(pady=10)

        self.remove_button = tk.Button(self.frame, text="Remove Selected Activity", command=self.remove_selected_activity)
        self.remove_button.pack(pady=5)

        self.load_registered_activities()

    def load_registered_activities(self):
        self.activities_listbox.delete(0, tk.END)
        self.activities = self.resident.get_registered_activities()
        for act in self.activities:
            display = f"{act[1]} - {act[2]}"  # title - startdate
            self.activities_listbox.insert(tk.END, display)

    def remove_selected_activity(self):
        selection = self.activities_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select an activity.")
            return

        index = selection[0]
        activity_id = self.activities[index][0]

        try:
            self.resident.unregister_from_activity(activity_id)
            messagebox.showinfo("Success", "Successfully removed from the activity.")
            self.load_registered_activities()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to remove: {e}")
