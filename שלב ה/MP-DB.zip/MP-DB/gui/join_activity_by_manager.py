import tkinter as tk
from tkinter import ttk, messagebox
from db.resident import Resident

class JoinActivityByManager:
    def __init__(self, master):
        self.frame = ttk.Frame(master)
        self.resident_id_var = tk.StringVar()

        tk.Label(self.frame, text="Register Resident to Activity", font=("Arial", 16)).pack(pady=10)
        form = tk.Frame(self.frame)
        form.pack(pady=10)
        tk.Label(form, text="Resident ID:").grid(row=0, column=0, sticky='e')
        tk.Entry(form, textvariable=self.resident_id_var).grid(row=0, column=1)

        tk.Button(self.frame, text="Load Available Activities", command=self.load_activities).pack(pady=5)

        self.activities_listbox = tk.Listbox(self.frame, height=12, width=80)
        self.activities_listbox.pack(pady=10)

        tk.Button(self.frame, text="Register", command=self.register).pack(pady=5)

    def load_activities(self):
        rid = self.resident_id_var.get()
        if not rid.isdigit():
            messagebox.showerror("Error", "Please enter a valid numeric resident ID.")
            return
        self.resident = Resident(int(rid))
        self.activities = self.resident.get_available_activities()
        self.activities_listbox.delete(0, tk.END)
        for act in self.activities:
            display = f"{act[1]} - {act[2]} | {act[3]} | {act[4]}"
            self.activities_listbox.insert(tk.END, display)

    def register(self):
        sel = self.activities_listbox.curselection()
        if not sel:
            messagebox.showwarning("No Selection", "Please select an activity.")
            return
        try:
            activity_id = self.activities[sel[0]][0]
            self.resident.register_to_activity(activity_id)
            messagebox.showinfo("Success", "Resident registered successfully.")
            self.load_activities()
        except Exception as e:
            messagebox.showerror("Error", f"Registration failed: {e}")
